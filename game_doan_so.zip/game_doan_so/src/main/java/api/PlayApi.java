package api;

import com.google.gson.Gson;
import model.User;
import payload.BasicResponse;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.Comparator;

import static servlet.LoginServlet.userList;

@WebServlet(name = "PlayApi", urlPatterns = "/api/play")
public class PlayApi extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Nhận số ngươì chơi đoán từ reques
        int num = Integer.parseInt(req.getParameter("num"));

        // Lấy thông tin user và số ngẫu nhiên từ session đã tạo
        HttpSession session = req.getSession();
        int random = (int) session.getAttribute("random");
        User user = (User) session.getAttribute("user");

        // Tăng số lần đoán và set cho user
        user.setNumGues(user.getNumGues() + 1);

        BasicResponse basicResponse = new BasicResponse();

        if (num < random){
            basicResponse.setMessage("Bé hơn số cần đoán, mời bạn đoán lại");
            basicResponse.setData(1);
            basicResponse.setStatus(200);
        } else if (num > random) {
            basicResponse.setMessage("Lớn hơn số cần đoán, mời bạn đoán lại");
            basicResponse.setData(1);
            basicResponse.setStatus(200);
        } else {
            // Đúng thì thêm user vào list user đã tạo
            userList.add(user);

            // Xếp hạng lại người chơi
            Collections.sort(userList, new Comparator<User>() {
                @Override
                public int compare(User o1, User o2) {
                    int cmp = Integer.compare(o1.getNumGues(), o2.getNumGues());
                    return cmp;
                }
            });
            String data = "Bạn đã trả lời đúng sau " + user.getNumGues() +
                    " lần đoán, xếp hạng: " + (userList.indexOf(user) +1);

            basicResponse.setMessage("Chính xác");
            basicResponse.setData(data);
            basicResponse.setStatus(200);
        }

        Gson gson = new Gson();
        String dataJson = gson.toJson(basicResponse);

        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        PrintWriter out = resp.getWriter();
        out.println(dataJson);
        out.flush();
    }
}
