package servlet;

import model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.*;

@WebServlet(name = "LoginServlet", urlPatterns = "")
public class LoginServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("login.jsp").forward(req, resp);
    }
    // Khai báo id cho User
    private static int id = -1;
    // Tạo list lưu trữ thông tin người chơi
    public static List<User> userList = new ArrayList<>();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String name = req.getParameter("name");

        // Xếp hạng những người chơi đã hoàn thành theo thứ tự tăng dần số lần đoán
        Collections.sort(userList, new Comparator<User>() {
            @Override
            public int compare(User o1, User o2) {
                int cmp = Integer.compare(o1.getNumGues(), o2.getNumGues());
                return cmp;
            }
        });

        // Tạo số ngẫu nhiên từ 1 - 1000
        Random rand = new Random();
        int random = rand.nextInt(1001);

        // Set id cho mỗi user theo thứ tự tăng dần
        // để phân biệt user tránh trường hợp trùng tên
        id = id + 1;
        User user = new User();
        user.setId(id);
        user.setName(name);
        user.setNumGues(0);

        // Tạo session lưu trữ user và số ngẫu nhiên
        HttpSession session = req.getSession();
        session.setAttribute("user", user);
        session.setAttribute("random", random);
        session.setMaxInactiveInterval(8 * 60 * 60);
        System.out.println("Số ngẫu nhiên là: " + random);

        // Trả về url mới cho người dùng
        resp.sendRedirect(req.getContextPath() + "http://localhost:8081/play");
    }
}
