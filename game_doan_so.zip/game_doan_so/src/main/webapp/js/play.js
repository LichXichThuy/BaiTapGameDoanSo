$(document).ready(function (){
    $('#btn-guess').click(function (e){
        e.preventDefault()
        const num = $('#num-guess').val()

        $.ajax({
            method: 'POST',
            url: `http://localhost:8081/api/play`,
            data:{
                'num': num,
            }
        }).done(function (data){
            if (data.data == 1){
                document.getElementById('alert').innerHTML = data.message
            } else{
                alert(data.data)
                window.location.replace('http://localhost:8081')
            }
        })
    })
});